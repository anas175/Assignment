import React from "react";
import Navbar from "./navbar";
function App(){
    return(
        <div>
            <Navbar/>
            
        </div>
    
    );
}
export default App;